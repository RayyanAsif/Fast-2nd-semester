#include <iostream>
#include "Calculator.h"
using namespace std;
int main(){
	Calculator c1(10,5);
	c1.add();
	c1.subtract();
	c1.divide();
	c1.multiply();
}
