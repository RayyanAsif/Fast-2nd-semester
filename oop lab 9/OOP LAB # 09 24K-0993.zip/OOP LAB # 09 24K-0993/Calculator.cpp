#ifndef CALCULATOR
#define CALCULATOR

class Calculator{
	private:
		int a;
		int b;
	public:
		Calculator(int a,int b);
		void add();
		void subtract();
		void multiply();
		void divide();
};
#endif
